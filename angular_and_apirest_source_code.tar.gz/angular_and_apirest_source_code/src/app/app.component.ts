import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'VoIP Firewall';

  constructor() {
    var url = location.pathname.substr(location.pathname.lastIndexOf("/") + 1);

    var sessid = localStorage.getItem("sessid");
    var user = localStorage.getItem("user");
  }
}
