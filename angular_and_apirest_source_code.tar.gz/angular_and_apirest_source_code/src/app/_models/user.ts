export class User {
    user: string;
    pass: string;
}