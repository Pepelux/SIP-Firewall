export class Blacklist {
    id: number;
    value: string;
    description: string;
    ban: string;
    action: string;
    code: string;
    text: string;
}