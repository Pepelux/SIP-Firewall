import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { User } from '../_models/user';
import { PeticionesService } from '../_services/peticiones.service';
import { routerTransition } from '../router.animations';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  animations: [routerTransition()],
  providers: [PeticionesService]
})
export class LoginComponent implements OnInit {
  public logindata: User;
  public errorform: boolean;

  constructor(
    private router: Router,
    private _peticionesService: PeticionesService
  ) {
    this.logindata = new User();
    this.logindata.user = "";
    this.logindata.pass = "";
    this.errorform = false;
  }

  ngOnInit() {
  }

  onSubmit() {
    this._peticionesService.getUser(this.logindata.user, this.logindata.pass).subscribe(
      result => {
        if (result.token != '') {
          localStorage.setItem('isLoggedin', 'true');
          localStorage.setItem('token', result.token);
          localStorage.setItem('user', this.logindata.user);
          if (this.logindata.pass == 'admin')
            this.router.navigate(['./password']);
          else
            this.router.navigate(['./blacklist']);
        }
        else this.errorform = true;
      },
      error => {
        console.log(<any>error);
      }
    );
  }
}
