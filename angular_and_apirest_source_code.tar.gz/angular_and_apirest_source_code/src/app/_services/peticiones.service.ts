import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class PeticionesService {
    public url: string;

    constructor(
        public _http: HttpClient
    ) {
        var file = '/assets/url.conf';
        var rawFile = new XMLHttpRequest();
        var urltmp = 'http://localhost/';
        rawFile.open("GET", file, false);
        rawFile.onreadystatechange = function () {
            if (rawFile.readyState === 4) {
                if (rawFile.status === 200 || rawFile.status == 0) {
                    var allText = rawFile.responseText;
                    urltmp = allText;
                }
            }
        }
        rawFile.send(null);
        this.url = urltmp;
    }

    getUser(user: string, pass: string): Observable<any> {
        const body = JSON.stringify({
            user: user,
            pass: pass
        });

        return this._http.post(this.url + '/validate.php', body);
    }

    // ***** Blacklist *****
    getBlacklist(
        id: number,
        page: number,
        end: number,
        type: string,
        order: string,
        dir: string
    ): Observable<any> {
        const body = JSON.stringify({
            user: localStorage.getItem('user'),
            token: localStorage.getItem('token'),
            id: id,
            page: page,
            end: end,
            type: type,
            order: order,
            dir: dir
        });

        return this._http.post(this.url + '/blacklist.php', body);
    }

    updateBlacklist(
        id: number,
        value: string,
        detail: string,
        ban: string,
        action: string,
        code: string,
        text: string
    ): Observable<any> {
        const body = JSON.stringify({
            user: localStorage.getItem('user'),
            token: localStorage.getItem('token'),
            id: id,
            value: value,
            detail: detail,
            ban: ban,
            action: action,
            code: code,
            text: text
        });

        return this._http.post(this.url + '/blacklist_update.php', body);
    }

    createBlacklist(
        value: string,
        detail: string,
        ban: string,
        action: string,
        code: string,
        text: string,
        type: string
    ): Observable<any> {
        const body = JSON.stringify({
            user: localStorage.getItem('user'),
            token: localStorage.getItem('token'),
            value: value,
            detail: detail,
            ban: ban,
            action: action,
            code: code,
            text: text,
            type: type
        });

        return this._http.post(this.url + '/blacklist_add.php', body);
    }

    deleteBlacklist(
        id: number
    ): Observable<any> {
        const body = JSON.stringify({
            user: localStorage.getItem('user'),
            token: localStorage.getItem('token'),
            id: id
        });

        return this._http.post(this.url + '/blacklist_delete.php', body);
    }

    isBlacklisted(
        type: string,
        value: string
    ): Observable<any> {
        const body = JSON.stringify({
            user: localStorage.getItem('user'),
            token: localStorage.getItem('token'),
            type: type,
            value: value
        });

        // console.log(this.url + '/isblacklisted.php -d \''+ body +'\'');
        return this._http.post(this.url + '/isblacklisted.php', body);
    }

    // ***** Whitelist *****
    getWhitelist(
        id: number,
        page: number,
        end: number,
        type: string,
        order: string,
        dir: string
    ): Observable<any> {
        const body = JSON.stringify({
            user: localStorage.getItem('user'),
            token: localStorage.getItem('token'),
            id: id,
            page: page,
            end: end,
            type: type,
            order: order,
            dir: dir
        });

        return this._http.post(this.url + '/whitelist.php', body);
    }

    updateWhitelist(
        id: number,
        value: string,
        detail: string
    ): Observable<any> {
        const body = JSON.stringify({
            user: localStorage.getItem('user'),
            token: localStorage.getItem('token'),
            id: id,
            value: value,
            detail: detail
        });

        return this._http.post(this.url + '/whitelist_update.php', body);
    }

    createWhitelist(
        value: string,
        detail: string,
        type: string
    ): Observable<any> {
        const body = JSON.stringify({
            user: localStorage.getItem('user'),
            token: localStorage.getItem('token'),
            value: value,
            detail: detail,
            type: type
        });

        console.log(this.url + '/whitelist_add.php --data ' + body);
        return this._http.post(this.url + '/whitelist_add.php', body);
    }

    deleteWhitelist(
        id: number
    ): Observable<any> {
        const body = JSON.stringify({
            user: localStorage.getItem('user'),
            token: localStorage.getItem('token'),
            id: id
        });

        return this._http.post(this.url + '/whitelist_delete.php', body);
    }

    // Stats
    getCause(
        g: number,
        type: string
    ): Observable<any> {
        const body = JSON.stringify({
            user: localStorage.getItem('user'),
            token: localStorage.getItem('token'),
            g: g,
            type: type
        });

        return this._http.post(this.url + '/resume-stats.php', body);
    }

    // Destinations
    getDestinations(
        t: string,
        country: string,
        type: string,
        customvalue: string
    ): Observable<any> {
        const body = JSON.stringify({
            user: localStorage.getItem('user'),
            token: localStorage.getItem('token'),
            t: t,
            country: country,
            type: type,
            customvalue: customvalue
        });

        return this._http.post(this.url + '/destination.php', body);
    }

    // Bloqueados
    getBlocked(
        id: number,
        filters: any,
        page: number,
        end: number,
        order: string,
        dir: string
    ): Observable<any> {
        const body = JSON.stringify({
            user: localStorage.getItem('user'),
            token: localStorage.getItem('token'),
            id: id,
            filters: filters,
            page: page,
            end: end,
            order: order,
            dir: dir
        });

        return this._http.post(this.url + '/blocked.php', body);
    }

    // Permitidos
    getAllowed(
        id: number,
        filters: any,
        page: number,
        end: number,
        order: string,
        dir: string
    ): Observable<any> {
        const body = JSON.stringify({
            user: localStorage.getItem('user'),
            token: localStorage.getItem('token'),
            id: id,
            filters: filters,
            page: page,
            end: end,
            order: order,
            dir: dir
        });

        // console.log(this.url + '/allowed.php -d \'' + body + '\'');
        return this._http.post(this.url + '/allowed.php', body);
    }

    // Paises
    getCountries(
    ): Observable<any> {
        return this._http.post(this.url + '/country_code.php', '');
    }

    // Configuración
    getConfig(
        field: string
    ): Observable<any> {
        const body = JSON.stringify({
            user: localStorage.getItem('user'),
            token: localStorage.getItem('token'),
            field: field
        });

        return this._http.post(this.url + '/config.php', body);
    }

    updateConfig(
        field: string,
        value: string,
        matches: string
    ): Observable<any> {
        const body = JSON.stringify({
            user: localStorage.getItem('user'),
            token: localStorage.getItem('token'),
            field: field,
            value: value,
            matches: matches
        });

        return this._http.post(this.url + '/config.php', body);
    }

    // Cambio de contraseña
    updatePassword(
        login: string,
        oldpass: string,
        newpass: string
    ): Observable<any> {
        const body = JSON.stringify({
            user: localStorage.getItem('user'),
            token: localStorage.getItem('token'),
            login: login,
            oldpass: oldpass,
            newpass: newpass
        });

        return this._http.post(this.url + '/password.php', body);
    }
}